from moviepy.editor import *

video_clip = VideoFileClip("task01.mp4")
video_clip = video_clip.subclip(0,6)
video_clip.write_gif("task1.gif",fps = 140)
gif_video_clip = VideoFileClip("task1.gif")
gif_video_clip.ipython_display()